---
title: "Body"
date: 2019-10-17T11:22:16+06:00
draft: false

# meta description
description : "For body fitness"

# product Price
price: "30.00$"
priceBefore: ""

# Product Short Description
shortDescription: "La Néo is a cosmetic clinic specializing in skin and body rejuvenation, contouring, slimming, tightening, and weight loss."

#product ID
productID: "7"

# type must be "services"
type: "services"

# product Images
# first image will be shown in the product page
images:
  - image: "images/prod/active-84646_1280.jpg"
  - image: "images/prod/active-84646_1280.jpg"
  - image: "images/prod/dancers-384574_1280.jpg"
  - image: "images/prod/dancers-384574_1280.jpg"
---

Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea 

takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.

Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.