---
title: "Face"
date: 2019-10-17T11:22:16+06:00
draft: false

# meta description
description : "For face beauty"

# product Price
price: "20.00$"
priceBefore: "25.00$"

# Product Short Description
shortDescription: "La Néo is a cosmetic clinic specializing in skin and body rejuvenation, contouring, slimming, tightening, and weight loss."

#product ID
productID: "2"

# type must be "services"
type: "services"

# product Images
# first image will be shown in the product page
images:
  - image: "images/prod/girl-2771001_1280.jpg"
  - image: "images/prod/girl-2771001_1280.jpg"
  - image: "images/prod/girl-2771001_1280.jpg"
  - image: "images/prod/girl-2771001_1280.jpg"
---

La Néo is a cosmetic clinic specializing in skin and body rejuvenation, contouring, slimming, tightening, and weight loss. 

Whether you want to minimize the signs of aging or enhance the appearance of your face, skin, and body. 

Our advanced cosmetic technology will deliver the results you always dreamed of—without surgery, with no downtime, and risk-free.