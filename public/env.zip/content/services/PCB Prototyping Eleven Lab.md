---
title: "PCB Prototyping Eleven Lab "
date: 2012-12-17T11:22:16+06:00
images: 
  - image: "images/product/electronics/11lab_2011.jpg"
  - image: "images/product/electronics/11lab_2020.jpg"
  - image: "images/product/electronics/11lab_2011.jpg"
  - image: "images/product/electronics/11lab_2020.jpg"

# meta description
description : "PCB Prototyping Machine - Eleven lab"

# Product Short Description
shortDescription: "Product description."

tags : [
    "Electronics", 
    "PCB Prototyping",
    "Eleven Lab"
]

# product Price
price: "Ask for price"
priceBefore: ""


draft: false
---

 ### PCB Prototyping
* This product is equipped with higher-quality pressure foot which provides better capability of the milling width consistancy and the vacuum cleaning efficiency.

#### Even Lab

* Low-cost, wide range table size, XYZ triple-axes control, high resolution,
standard camera monitoring system
Suitable for processing normal PCB.


* Model: Even Lab, Even Lab +

* Magnify the surface of the board and display on a monitor.
You can easily adjust the right position while viewing display.
(Maximum useful magnification depends on the size of the screen)

* For information & inquiry,
* [Call now](callto:+8801517182063)
* [Email now](mailto:sales@enviotech.com.bd)