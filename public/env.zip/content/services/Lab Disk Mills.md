---
title: "Lab Disk Mills"
date: 2014-11-17T11:22:16+06:00
images: 
  - image: "images/product/milling/dm-1.jpg"
  - image: "images/product/milling/dm-2.jpg"
  - image: "images/product/milling/dm-1.jpg"
  - image: "images/product/milling/dm-2.jpg"

# meta description
description : "Lab Disk Mills Machine"

# Product Short Description
shortDescription: "Product description."

tags : [
    "Milling", 
    "Disk Mills"
    
]

# product Price
price: "Ask for price"
priceBefore: ""

draft: false
---

* RETSCH Vibratory Disk Mills are especially appropriate for fast, misfortune free granulating of hard, weak and stringy materials to diagnostic fineness. The factories are principally utilized for test groundwork for ghastly examination. 
Because of their hearty development plate factories are utilized under unpleasant conditions in research centers and pilot plants, just as online for the quality control of crude materials.
* Model: RS 200, RS 300, DM 200, DM 400. 
* For information & inquiry,
* [Call now](callto:+8801517182063)
* [Email now](mailto:sales@enviotech.com.bd)
***