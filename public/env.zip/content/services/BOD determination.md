---
title: "Laboratory BOD Tester"
date: 2017-10-17T11:22:16+06:00
image: "images/product/water/bd600_glp_mb2_01.jpg"
images: 
   - image: "images/product/water/bd600_glp_mb2_01.jpg"
   - image: "images/product/water/bd600_glp_mb2_01.jpg"  
   - image: "images/product/water/bd600_glp_mb2_01.jpg"  
   - image: "images/product/water/bd600_glp_mb2_01.jpg"
  
# meta description
description : "Get Spectrophotometers for water testing"

# Product Short Description
shortDescription: "Product description."

tags : [
     "Analytical Instruments",
     "Water Testing", 
     "BOD Determination tester"
    
]

# product Price
price: "Ask for price"
priceBefore: ""


draft: false
---


* Model: BD 600 GLP- Respirometric measuring system optimized for biodegradability tests under GLP conditions
* The BD 600 is a respirometric system for the determination of Biochemical Oxygen Demand (BOD). Save time, reduce the potential for errors and easily interpret data to help make process control decisions for your plant.
* Model: BD 606 - Accurate, automatic and direct control of your wastewater samples Mark as favourite

* For information & inquiry,
* [Call now](callto:+8801517182063)
* [Email now](mailto:sales@enviotech.com.bd)
***