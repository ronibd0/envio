---
title: "Lab Mortar Grinder Machine"
date: 2020-04-13T11:22:16+06:00
images: 
  - image: "images/product/milling/mg-1.jpg"
  - image: "images/product/milling/mg-2.jpg"
  - image: "images/product/milling/mg-1.jpg"
  - image: "images/product/milling/mg-2.jpg"

# meta description
description : "Laboratory Mortar Grinder Machines"

# Product Short Description
shortDescription: "Product description."

# product Price
price: "Ask for price"
priceBefore: ""

tags : [
    "Milling", 
    "Mortar Grinder"
    
]


draft: false
---

* Application: ashes, cement clinker, chemical products, coal, cocoa nibs, coke, drugs, food, homeopathic materials, nuts, oil seeds, pharmaceutical materials, plant materials, salts, silicates, slag, soils, spices, tiles, yeast cells. 
* Model: Grinder RM 200

* For information & inquiry,
* [Call now](callto:+8801517182063)
* [Email now](mailto:sales@enviotech.com.bd)
***